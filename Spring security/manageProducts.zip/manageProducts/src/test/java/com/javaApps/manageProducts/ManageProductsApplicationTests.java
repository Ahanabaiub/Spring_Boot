package com.javaApps.manageProducts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManageProductsApplicationTests {

	@Test
	void contextLoads() {
	}

}
